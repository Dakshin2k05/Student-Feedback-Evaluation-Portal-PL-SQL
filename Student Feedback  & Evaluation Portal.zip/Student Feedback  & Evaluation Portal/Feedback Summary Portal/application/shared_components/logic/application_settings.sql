prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 209933
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>64117734394309694767
,p_default_application_id=>209933
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STUDENTFEADBACK'
);
null;
wwv_flow_imp.component_end;
end;
/
