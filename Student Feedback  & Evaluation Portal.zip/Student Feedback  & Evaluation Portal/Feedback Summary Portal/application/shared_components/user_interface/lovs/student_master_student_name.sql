prompt --application/shared_components/user_interface/lovs/student_master_student_name
begin
--   Manifest
--     STUDENT_MASTER.STUDENT_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>64117734394309694767
,p_default_application_id=>209933
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STUDENTFEADBACK'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(64828224697138675684)
,p_lov_name=>'STUDENT_MASTER.STUDENT_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'STUDENT_MASTER'
,p_return_column_name=>'STUDENT_ID'
,p_display_column_name=>'STUDENT_NAME'
,p_default_sort_column_name=>'STUDENT_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15639452895191
);
wwv_flow_imp.component_end;
end;
/
