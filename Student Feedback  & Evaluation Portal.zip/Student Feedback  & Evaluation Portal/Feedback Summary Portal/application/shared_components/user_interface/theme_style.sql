prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 209933
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>64117734394309694767
,p_default_application_id=>209933
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STUDENTFEADBACK'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(64929187522023652203)
,p_theme_id=>42
,p_name=>'Vita - Slate (copy_1)'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Slate.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-BG":"#1e63a4","@g_Link-Base":"#ce177f","@g_Container-BorderRadius":"0px","@g_Button-BorderRadius":"10px","@g_Form-BorderRadius":"30px"},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#64929187522023652203.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(65045843321375372304)
,p_theme_id=>42
,p_name=>'Vita - Slate (copy_2)'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Slate.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Container-BorderRadius":"30px","@g_Nav_Style":"light","@g_Button-BorderRadius":"24px","@g_Form-BorderRadius":"16px","@irrBg":"#261b1b","@Nav-Exp":"190px","@Side-Exp":"440px"},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#65045843321375372304.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(65087547531448344201)
,p_theme_id=>42
,p_name=>'Redwood Light (copy_1)'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_css_classes=>' rw-pillar--pine rw-layout--fixed t-PageBody--scrollTitle'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_config=>'{"classes":["rw-pillar--pine","rw-layout--fixed t-PageBody--scrollTitle"],"vars":{},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#65087547531448344201.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
