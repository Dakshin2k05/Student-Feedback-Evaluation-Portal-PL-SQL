prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>64117734394309694767
,p_default_application_id=>209933
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STUDENTFEADBACK'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Welcome to feedback form !!'
,p_alias=>'FEEDBACK'
,p_step_title=>'Welcome to feedback form !!'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64829331018486690486)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(64827641971747644393)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64829336314779690710)
,p_plug_name=>'Submit Feedback'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'STUDENT_FEEDBACK'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64829345329463690721)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P2_FEEDBACK_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64829344392494690720)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Reset'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>unistr(' \201CThis will clear all entered data. Are you sure you want to reset the form?\201D')
,p_confirm_style=>'warning'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64829345796911690721)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_button_name=>'SUBMIT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_button_condition=>'P2_FEEDBACK_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64829344934927690720)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P2_FEEDBACK_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(64829346050110690721)
,p_branch_action=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829336657390690711)
,p_name=>'P2_FEEDBACK_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Feedback Id'
,p_source=>'FEEDBACK_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829337035776690712)
,p_name=>'P2_STUDENT_ID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_prompt=>'Student Id'
,p_source=>'STUDENT_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT STUDENT_NAME || '' - '' || STUDENT_ID AS display_value, STUDENT_ID AS return_value',
'FROM STUDENT_MASTER;'))
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'Y',
  'match_type', 'CONTAINS_IGNORE',
  'max_values_in_list', '7',
  'min_chars', '1',
  'use_cache', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829337402064690712)
,p_name=>'P2_TEACHER_ID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_prompt=>'Teacher Id'
,p_source=>'TEACHER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TEACHER_NAME || '' - '' || TEACHER_ID AS display_value, TEACHER_ID AS return_value',
'FROM UNI_TEACHER;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829337860830690713)
,p_name=>'P2_COURSE_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_prompt=>'Course Code'
,p_source=>'COURSE_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT COURSE_NAME || '' - '' || COURSE_CODE AS display_value, COURSE_CODE AS return_value',
'FROM COURSE_MASTER;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829338257454690714)
,p_name=>'P2_RATING_CLARITY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_prompt=>'Rating Clarity'
,p_source=>'RATING_CLARITY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:1;1,2;2,3;3,4;4,5;5'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829338695876690714)
,p_name=>'P2_RATING_SUBJECT_KNOWLEDGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_prompt=>'Rating Subject Knowledge'
,p_source=>'RATING_SUBJECT_KNOWLEDGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:1;1,2;2,3;3,4;4,5;5'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829339025686690715)
,p_name=>'P2_RATING_COMMUNICATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_prompt=>'Rating Communication'
,p_source=>'RATING_COMMUNICATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:1;1,2;2,3;3,4;4,5;5'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829339470998690715)
,p_name=>'P2_RATING_EXAMPLES'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_prompt=>'Rating Examples'
,p_source=>'RATING_EXAMPLES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:1;1,2;2,3;3,4;4,5;5'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829339881613690716)
,p_name=>'P2_RATING_TEACHING_AIDS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_prompt=>'Rating Teaching Aids'
,p_source=>'RATING_TEACHING_AIDS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:1;1,2;2,3;3,4;4,5;5'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829340258597690716)
,p_name=>'P2_RATING_INTERACTION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_prompt=>'Rating Interaction'
,p_source=>'RATING_INTERACTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:1;1,2;2,3;3,4;4,5;5'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64829340682345690717)
,p_name=>'P2_FEEDBACK_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_item_source_plug_id=>wwv_flow_imp.id(64829336314779690710)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Feedback Date'
,p_source=>'FEEDBACK_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(64945520795283068501)
,p_name=>'Insert_New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(64829345796911690721)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64945520895056068502)
,p_event_id=>wwv_flow_imp.id(64945520795283068501)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'INSERT INTO STUDENT_FEEDBACK (',
'  STUDENT_ID,',
'  TEACHER_ID,',
'  COURSE_CODE,',
'  RATING_CLARITY,',
'  RATING_SUBJECT_KNOWLEDGE,',
'  RATING_COMMUNICATION,',
'  RATING_EXAMPLES,',
'  RATING_TEACHING_AIDS,',
'  RATING_INTERACTION',
')',
'VALUES (',
'  :P2_STUDENT_ID,',
'  :P2_TEACHER_ID,',
'  :P2_COURSE_CODE,',
'  :P2_RATING_CLARITY,',
'  :P2_RATING_SUBJECT_KNOWLEDGE,',
'  :P2_RATING_COMMUNICATION,',
'  :P2_RATING_EXAMPLES,',
'  :P2_RATING_TEACHING_AIDS,',
'  :P2_RATING_INTERACTION',
');',
'',
'-- Update or Insert into TEACHER_SUMMARY',
'MERGE INTO TEACHER_SUMMARY s',
'USING (',
'  SELECT',
'    ROUND(AVG(RATING_CLARITY), 2) AS AVG_CLARITY,',
'    ROUND(AVG(RATING_SUBJECT_KNOWLEDGE), 2) AS AVG_SUBJECT_KNOWLEDGE,',
'    ROUND(AVG(RATING_COMMUNICATION), 2) AS AVG_COMMUNICATION,',
'    ROUND(AVG(RATING_EXAMPLES), 2) AS AVG_EXAMPLES,',
'    ROUND(AVG(RATING_TEACHING_AIDS), 2) AS AVG_TEACHING_AIDS,',
'    ROUND(AVG(RATING_INTERACTION), 2) AS AVG_INTERACTION',
'  FROM STUDENT_FEEDBACK',
'  WHERE TEACHER_ID = :P2_TEACHER_ID',
'    AND COURSE_CODE = :P2_COURSE_CODE',
') avg_data',
'ON (s.TEACHER_ID = :P2_TEACHER_ID AND s.COURSE_CODE = :P2_COURSE_CODE)',
'WHEN MATCHED THEN',
'  UPDATE SET',
'    s.AVG_CLARITY      = avg_data.AVG_CLARITY,',
'    s.AVG_SUBJECT_KNOWLEDGE   = avg_data.AVG_SUBJECT_KNOWLEDGE,',
'    s.AVG_COMMUNICATION    = avg_data.AVG_COMMUNICATION,',
'    s.AVG_EXAMPLES     = avg_data.AVG_EXAMPLES,',
'    s.AVG_TEACHING_AIDS  = avg_data.AVG_TEACHING_AIDS,',
'    s.AVG_INTERACTION  = avg_data.AVG_INTERACTION,',
'    s.LAST_UPDATED     = SYSDATE',
'WHEN NOT MATCHED THEN',
'  INSERT (',
'    TEACHER_ID,',
'    COURSE_CODE,',
'    AVG_CLARITY,',
'    AVG_SUBJECT_KNOWLEDGE,',
'    AVG_COMMUNICATION,',
'    AVG_EXAMPLES,',
'    AVG_TEACHING_AIDS,',
'    AVG_INTERACTION,',
'    LAST_UPDATED',
'  )',
'  VALUES (',
'    :P2_TEACHER_ID,',
'    :P2_COURSE_CODE,',
'    avg_data.AVG_CLARITY,',
'    avg_data.AVG_SUBJECT_KNOWLEDGE,',
'    avg_data.AVG_COMMUNICATION,',
'    avg_data.AVG_EXAMPLES,',
'    avg_data.AVG_TEACHING_AIDS,',
'    avg_data.AVG_INTERACTION,',
'    SYSDATE',
'  );',
''))
,p_attribute_02=>'P2_STUDENT_ID,P2_TEACHER_ID,P2_COURSE_CODE,P2_RATING_CLARITY,P2_RATING_SUBJECT_KNOWLEDGE,P2_RATING_COMMUNICATION,P2_RATING_EXAMPLES,P2_RATING_TEACHING_AIDS,P2_RATING_INTERACTION,P2_FEEDBACK_DATE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(64829346963930690722)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(64829336314779690710)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Submit Feedback'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>64829346963930690722
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(64829346543234690722)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(64829336314779690710)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Submit Feedback'
,p_internal_uid=>64829346543234690722
);
wwv_flow_imp.component_end;
end;
/
